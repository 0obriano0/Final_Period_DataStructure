# -*- coding: utf-8 -*-
"""
Created on Fri Jun  7 16:14:03 2019

@author: 0obriano0
"""

import numpy as np