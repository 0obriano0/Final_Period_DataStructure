# -*- coding: utf-8 -*-
"""
Created on Tue May 28 20:49:06 2019

@author: asus
"""

import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import statistics

